TTK4115 - Part IV / Lab 4: filtered source data

Source: Del 4.zip (unaltered). This is a working separation, not a fresh measurement set.

Data/Task_4_1 : 5 unique recording contents; names start with task41
Data/Task_4_2 : 9 unique recording contents; names start with task42
Data/Task_4_3 : 33 unique recording contents; names start with task43
TOTAL: 47 unique recording contents (45 filenames + 2 additional older versions).

Excluded as not Part IV: task 31playing.mat, task34_u.mat (two versions),
task34_xhat.mat, task34_y.mat, task 2b byson.mat, taskpocomneg1j10.mat.
They are retained only in the original source ZIP, not in this filtered package.

Classification basis: original filenames and consistency with 2026 Part IV tasks.
For strict experiment provenance, verify with contemporaneous lab notes / model versions;
archived filenames do not prove which exact Simulink configuration produced each MAT file.

Model_reference/ contains the latest archived heli_q8.slx, IMU_heli_3_10.slx,
and init_heli_3_10.m. These models may contain logic from earlier lab parts and
represent the last saved state, not all per-trial configurations.

All MAT file contents are unchanged. The SHA256 manifest is included.
